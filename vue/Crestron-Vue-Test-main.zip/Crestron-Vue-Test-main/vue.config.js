module.exports = {
  publicPath: ''
}